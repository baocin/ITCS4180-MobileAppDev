//Michael Pedersen
//800810806
//InClass05
//2/15/12

package com.github.baocin.inclass05;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {
    String keyword;
    static ImageView displayImage;
    int keyIndex = 0;
    HashMap<String, ArrayList<String>> urls = new HashMap<String, ArrayList<String>>();
    ArrayList<String> urlList = new ArrayList<String>();
    String dictUrl = "http://dev.theappsdr.com/apis/spring_2016/inclass5/URLs.txt";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        urlList = new ArrayList<String>();

        findViewById(R.id.nextButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                keyIndex += 1;
                keyIndex %= urlList.size();
                if (!isOnline()) {
                    Toast.makeText(MainActivity.this, "No Network Connection", Toast.LENGTH_SHORT).show();
                }
                try {
                    Bitmap bm = new GetImage().execute(urls.get(keyword).get(keyIndex)).get();
                    ((ImageView) findViewById(R.id.img)).setImageBitmap(bm);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }

            }
        });
        findViewById(R.id.prevButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                keyIndex -= 1;
                keyIndex %= urlList.size();
                if (!isOnline()){
                    Toast.makeText(MainActivity.this, "No Network Connection", Toast.LENGTH_SHORT).show();
                }
                try {
                    Bitmap bm = new GetImage().execute(urls.get(keyword).get(keyIndex)).get();
                    ((ImageView) findViewById(R.id.img)).setImageBitmap(bm);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }

            }
        });
        displayImage = (ImageView) findViewById(R.id.img);
        findViewById(R.id.go).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                keyword = ((EditText) findViewById(R.id.keyword)).getText().toString();
                BufferedReader reader = null;
                try {
                    urls = new GetDictionary().execute(dictUrl).get();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }

                if (keyword.equals("UNCC") || keyword.equals("winter") || keyword.equals("aurora") || keyword.equals("wonders")) {

                    urlList = urls.get(keyword);

                    try {
                        Bitmap bm = new GetImage().execute(urlList.get(0)).get();
                        ((ImageView) findViewById(R.id.img)).setImageBitmap(bm);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    }

                }


            }

        });
    }

    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            return true;
        }
        return false;
        //networkInfo.getType can get type of connection
    }





}

