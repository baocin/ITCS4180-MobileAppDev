package com.github.baocin.inclass05;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by aoi on 2/15/16.
 */

class GetImage extends AsyncTask<String, Void, Bitmap> {
    /*
    open connection with buffered reader. Use stringbuilder to append all data you receive and send to one string at the end.
     */
    @Override
    protected Bitmap doInBackground(String... params) {
        InputStream in = null;
        try {
            URL url = new URL(params[0]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET"); //con.setRequestMethod("POST");= new BufferedReader(new InputStreamReader(connection.getInputStream()));
            in = connection.getInputStream();
            Bitmap image = BitmapFactory.decodeStream(in);
            return image;

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return null;
    }
}



