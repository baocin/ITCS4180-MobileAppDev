package com.github.baocin.inclass05;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.MalformedInputException;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by aoi on 2/15/16.
 */


class GetDictionary extends AsyncTask<String, Void, HashMap<String, ArrayList<String>>> {
    /*
    open connection with buffered reader. Use stringbuilder to append all data you receive and send to one string at the end.
     */
    @Override
    protected HashMap<String, ArrayList<String>> doInBackground(String... params) {
        BufferedReader reader = null;
        ArrayList<String> strings;
        try {
            URL url = new URL(params[0]);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET"); //con.setRequestMethod("POST");
            reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = "";
            while((line = reader.readLine()) != null) {
                sb.append(line);

            }
            reader.close();
            Log.d("SB", sb.toString());
            String dictionary = sb.toString();
            Log.d("Dictionary", dictionary.toString());
            HashMap<String, ArrayList<String>> hm = new HashMap<String, ArrayList<String>>();
            for (String elements : dictionary.split(";")) {
                // Log.d("String element", elements);
                String[] splitElement = elements.split(",");
                Log.d("Size before: ", ""+ splitElement.length);
                for (int i = 0; i < splitElement.length; i++) {
                    Log.d("Size in loop", ""+splitElement.length);
                }
                Log.d("size after loop" ,""+ splitElement.length);
                String key = splitElement[0];
                String value = splitElement[1];

                try {
                    hm.get(key).add(value);
                } catch (Exception e) {
                    hm.put(key, new ArrayList<String>());
                    hm.get(key).add(value);
                }

            }
            Log.d("Hashmap", hm.toString());
            return hm;
        } catch (MalformedInputException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (reader != null)
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
        return null;
    }
}
