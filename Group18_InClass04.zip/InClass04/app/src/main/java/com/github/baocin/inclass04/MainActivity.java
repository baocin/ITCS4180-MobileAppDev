
/** MainActivity
 *  Assignment Inclass 04
 *  Group #18
 *
 *  Students:
 *  Gabriel Lima
 *  Praveenkumar Sangalad
 *  Michael Pedersen
 *
 **/

package com.github.baocin.inclass04;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    ProgressDialog progressDialog;

    int selectedSpinnerItem = -1;
    boolean num = false;
    boolean upper = false;
    boolean lower = false;
    boolean special = false;

    private Handler handler = new Handler(new Handler.Callback() {
        @Override
        public boolean handleMessage(Message msg) {
            Log.d("Msg", msg.getData().toString());
            switch (msg.what) {
                case threadPasswordWord.STATUS_START:
                    progressDialog.show();
                    break;
                case threadPasswordWord.STATUS_STOP:
                    progressDialog.dismiss();
                    break;
            }
            if (msg.getData().containsKey("resultPassword")) {
                String resultPassword = msg.getData().getString("resultPassword");
                ((TextView) findViewById(R.id.output)).setText(resultPassword);
            }

            return false;
        }
    });

    class threadPasswordWord implements Runnable {
        static final int STATUS_START = 0;
        static final int STATUS_STOP = 1;

        public threadPasswordWord(){
            Log.d("Inside of a thread!", "");
            num = ((CheckBox)findViewById(R.id.numbersCheckbox)).isChecked();
            upper = ((CheckBox)findViewById(R.id.uppercaseCheckbox)).isChecked();
            lower = ((CheckBox)findViewById(R.id.lowercaseCheckbox)).isChecked();
            special = ((CheckBox)findViewById(R.id.specialCheckbox)).isChecked();
            if (!(num || upper || lower || special)){
                Toast.makeText(getBaseContext(), R.string.noCheckboxSelectedErrorText, Toast.LENGTH_SHORT).show();
            }

        }

        @Override
        public void run() {
            Log.d("In Background Thread", "");
            Message msg = new Message();
            msg.what = STATUS_START;
            handler.sendMessage(msg);


            String resultPassword = Util.getPassword(selectedSpinnerItem, num, upper, lower, special);
            Bundle b = new Bundle();
            b.putString("resultPassword", resultPassword);
            msg = new Message();
            msg.setData(b);
            handler.sendMessage(msg);

            msg = new Message();
            msg.what = STATUS_STOP;
            handler.sendMessage(msg);

        }
    }

    class asyncPasswordWork extends AsyncTask<Integer, Integer, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            num = ((CheckBox)findViewById(R.id.numbersCheckbox)).isChecked();
            upper = ((CheckBox)findViewById(R.id.uppercaseCheckbox)).isChecked();
            lower = ((CheckBox)findViewById(R.id.lowercaseCheckbox)).isChecked();
            special = ((CheckBox)findViewById(R.id.specialCheckbox)).isChecked();
            if (!(num || upper || lower || special)){
                Toast.makeText(getBaseContext(), R.string.noCheckboxSelectedErrorText, Toast.LENGTH_SHORT).show();
            }
            progressDialog.show();

        }

        @Override
        protected String doInBackground(Integer... params) {
            Log.d("In Background Async", params.toString());
            return Util.getPassword(selectedSpinnerItem, num, upper, lower, special);
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
//            Log.d("MADE A PASSWORD ASYNC: ", s);
//            Log.d("Length", s.length() + "");
            ((TextView)findViewById(R.id.output)).setText(s);
            progressDialog.dismiss();
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressDialog=new ProgressDialog(MainActivity.this);
        progressDialog.setMessage(getString(R.string.loadingMessage));
        progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progressDialog.setCancelable(false);

        Spinner spinner = (Spinner) findViewById(R.id.passwordLengthSpinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item) {

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                View v = super.getView(position, convertView, parent);
                return v;
            }

            @Override
            public int getCount() {
                return super.getCount()-1; // you dont display last item. It is used as hint.
            }

        };

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adapter.addAll(getResources().getStringArray( R.array.passwordLengthEntries));
        adapter.add(getString(R.string.spinnerText));


        spinner.setAdapter(adapter);
        spinner.setSelection(adapter.getCount()); //display hint


        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedSpinnerItem = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        ((Button) findViewById(R.id.generateAsync)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedSpinnerItem == 3){
                    Toast.makeText(getBaseContext(), getString(R.string.selectPasswordLengthErrorText), Toast.LENGTH_SHORT).show();
                }else{
                    new asyncPasswordWork().execute();
                }


            }
        });

        ((Button) findViewById(R.id.generateThread)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedSpinnerItem == 3){
                    Toast.makeText(getBaseContext(), getString(R.string.selectPasswordLengthErrorText), Toast.LENGTH_SHORT).show();
                }else{
                    new Thread(new threadPasswordWord()).start();
                }
            }

        });




    }





}
