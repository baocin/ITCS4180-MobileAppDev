//File:PrintActivity
//Assignment #: HW02
//Group 18
//Name: Michael Pedersen, Gabriel Lima,praveenkumar Sangalad

package com.example.gbl.homework02;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class PrintActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_print);
        setTitle(R.string.printTicket);

        Ticket ticket = (Ticket) getIntent().getExtras().get("ticket");
        Log.d("Print activity ticket: ", ticket.toString());

        ((TextView)findViewById(R.id.nameOutput)).setText(ticket.getName());
        ((TextView)findViewById(R.id.sourceOutput)).setText(ticket.getSource());
        ((TextView)findViewById(R.id.destinationOutput)).setText(ticket.getDestination());
        ((TextView)findViewById(R.id.departureOutput)).setText(ticket.getDepartureDate() + ", " + ticket.getDepartureTime());
        if (!ticket.getReturnDate().toString().isEmpty()) {
            ((TextView) findViewById(R.id.returnOutput)).setText(ticket.getReturnDate() + ", " + ticket.getReturnTime());
        }

        findViewById(R.id.finishButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }
}
