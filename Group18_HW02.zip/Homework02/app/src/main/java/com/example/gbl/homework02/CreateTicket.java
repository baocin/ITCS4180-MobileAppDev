package com.example.gbl.homework02;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class CreateTicket extends AppCompatActivity {
    static final List<String> locations = Arrays.asList("Albany, NY", "Atlanta, GA", "Boston, Ma", "Charlotte, NC", "Chicago, IL", "Greenville, SC", "Houston, TX", "Las Vegas, NV", "Los Angeles, CA", "Miami, FL", "Myrtle Beach, SC", "New York, NY", "Portland, OR", "Raleight, NC", "San Jose, CA", "Washington, DC");
    static final int DATE_DIALOG_ID = 0;
    static final int TIME_DIALOG_ID = 1;
    static ArrayList<Ticket> ticketList = new ArrayList<Ticket>();
    private SimpleDateFormat dateFormatter;
    private DatePickerDialog departureDatePickerDialog;
    private DatePickerDialog returnPickerDialog;
    private TimePickerDialog departureTimepickerdialog;
    private TimePickerDialog returnTimepickerDialog;
    private View returnDateInput;
    private View returnTimeInput;
    private EditText departureTimeInput;
    private EditText departureDateInputText;
    private View departureDateInput;
    private Calendar departureDate;
    private Calendar returnDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_ticket);
        setTitle(R.string.createTicket);
        final EditText sourceInput = (EditText) findViewById(R.id.sourceInput);
        final EditText destinationInput = (EditText) findViewById(R.id.destinationInput);

        returnDateInput = findViewById(R.id.returnDateInput);
        returnTimeInput = findViewById(R.id.returnTimeInput);
        departureTimeInput = ((EditText) findViewById(R.id.departureTimeInput));
        departureDateInput = findViewById(R.id.departureDateInput);
        departureDateInputText = ((EditText) departureDateInput);

//        //Test Ticket
//        Ticket test = new Ticket("04:05 PM", "06/06/16", "name", "Charlotte, NC", "Charlotte, NC", true);
//        ticketList.add(test);



//        ((EditText) findViewById(R.id.departureDateInput)).setKeyListener();

        final AlertDialog.Builder sourceLocationDialogBuilder = new AlertDialog.Builder(this);
        sourceLocationDialogBuilder.setTitle("Source").setItems((CharSequence[]) locations.toArray(), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Log.d("Location Dialog", locations.get(which) + " " + which);
                sourceInput.setText(locations.get(which));
                if (sourceInput.getText().toString().equals(destinationInput.getText().toString())) {
                    Toast.makeText(getApplicationContext(), "Error! The source and destination fields are the same!", Toast.LENGTH_SHORT).show();

                }
//                Log.d("Destination Check: ", );
//                Log.d("Destination Check: ", ((EditText) findViewById(R.id.destinationInput)).getText().toString());
            }
        });

        final AlertDialog.Builder destinationLocationDialogBuilder = new AlertDialog.Builder(this);
        destinationLocationDialogBuilder.setTitle("Destination").setItems((CharSequence[]) locations.toArray(), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Log.d("Location Dialog", locations.get(which) + " " + which);
                destinationInput.setText(locations.get(which));
                if (sourceInput.getText().toString().equals(destinationInput.getText().toString())) {
                    Toast.makeText(getApplicationContext(), "Error! The source and destination fields are the same!", Toast.LENGTH_SHORT).show();

                }
            }
        });

        findViewById(R.id.sourceInput).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sourceLocationDialogBuilder.show();
            }
        });

        findViewById(R.id.destinationInput).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                destinationLocationDialogBuilder.show();
            }
        });

        ((RadioButton) findViewById(R.id.onewayRadio)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((EditText) returnDateInput).setText(getString(R.string.empty));
                ((EditText) returnTimeInput).setText(getString(R.string.empty));

                returnDateInput.setAlpha(0);
                returnTimeInput.setAlpha(0);
            }
        });

        ((RadioButton) findViewById(R.id.roundRadio)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                returnDateInput.setAlpha(1);
                returnTimeInput.setAlpha(1);
            }
        });


        dateFormatter = new SimpleDateFormat("MM-dd-yyyy", Locale.US);
        Calendar newCalendar = Calendar.getInstance();
        departureDatePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                departureDate = Calendar.getInstance();
                departureDate.set(year, monthOfYear, dayOfMonth);
                departureDateInputText.setText(dateFormatter.format(departureDate.getTime()));
                if (returnDate != null && departureDate != null && returnDate.before(departureDate)){
                    Toast.makeText(getApplicationContext(), "Error! Return date is before departure date!", Toast.LENGTH_SHORT).show();

                }
            }
        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

        returnPickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                returnDate = Calendar.getInstance();
                returnDate.set(year, monthOfYear, dayOfMonth);
                ((EditText) returnDateInput).setText(dateFormatter.format(returnDate.getTime()));
                if (returnDate != null && departureDate != null && returnDate.before(departureDate)){
                    Toast.makeText(getApplicationContext(), "Error! Return date is before departure date!", Toast.LENGTH_SHORT).show();

                }
            }
        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

        departureTimeInput.setOnClickListener(new View.OnClickListener() {
                                                  @Override
                                                  public void onClick(View v) {
                                                      Calendar mcurrentTime = Calendar.getInstance();
                                                      int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                                                      int minute = mcurrentTime.get(Calendar.MINUTE);
                                                      TimePickerDialog mTimePicker;
                                                      mTimePicker = new TimePickerDialog(CreateTicket.this, new TimePickerDialog.OnTimeSetListener() {
                                                          @Override
                                                          public void onTimeSet(TimePicker timePicker, int hour, int minute) {
                                                              String timeScale = "AM";
                                                              if (!timePicker.is24HourView() && hour > 12) {
                                                                  hour -= 12;
                                                                  timeScale = "PM";
                                                              }
                                                              if (!timePicker.is24HourView() && hour >= 12 && minute >= 0) {
                                                                  timeScale = "PM";
                                                              }
//                        selectedHour = Math.abs(selectedHour);

                                                              DecimalFormat df = new DecimalFormat("00");
                                                              departureTimeInput.setText(df.format(hour) + ":" + df.format(minute) + " " + timeScale);
                                                          }
                                                      }, hour, minute, false);
                                                      mTimePicker.setTitle("Select Time");
                                                      mTimePicker.show();
                                                  }
                                              }

        );


        ((EditText)returnTimeInput).setOnClickListener(new View.OnClickListener() {
                                                           @Override
                                                           public void onClick(View v) {
                                                               Calendar mcurrentTime = Calendar.getInstance();
                                                               int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                                                               int minute = mcurrentTime.get(Calendar.MINUTE);
                                                               TimePickerDialog mTimePicker;
                                                               mTimePicker = new TimePickerDialog(CreateTicket.this, new TimePickerDialog.OnTimeSetListener() {
                                                                   @Override
                                                                   public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                                                                       if (!timePicker.is24HourView()) {
                                                                           selectedHour -= 12;

                                                                       }
                                                                       String isPm = selectedHour > 0 ? "PM" : "AM";
                                                                       selectedHour = Math.abs(selectedHour);

                                                                       DecimalFormat df = new DecimalFormat("00");
                                                                       ((EditText) returnTimeInput).setText(df.format(selectedHour) + ":" + selectedMinute + " " + isPm);
                                                                   }
                                                               }, hour, minute, false);
                                                               mTimePicker.setTitle("Select Time");
                                                               mTimePicker.show();
                                                           }
                                                       }

        );

            departureDateInput.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    departureDatePickerDialog.show();
                }
            });

            ((EditText)returnDateInput).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    returnPickerDialog.show();
                }
            });



            returnDateInput.setOnClickListener(new View.OnClickListener()

            {
                @Override
                public void onClick (View v){
                returnPickerDialog.show();
            }
            }

            );

            findViewById(R.id.finishButton).setOnClickListener(new View.OnClickListener() {
                                                                  @Override
                                                                  public void onClick(View view) {
                      Ticket newTicket = new Ticket();
                      newTicket.setDepartureDate(departureDateInputText.getText());
                      newTicket.setDepartureTime(departureTimeInput.getText());
                      newTicket.setReturnDate(((EditText) returnDateInput).getText());
                      newTicket.setReturnTime(((EditText) returnTimeInput).getText());
                      newTicket.setSource(((EditText) findViewById(R.id.sourceInput)).getText());
                      newTicket.setDestination(((EditText) findViewById(R.id.destinationInput)).getText());

                      newTicket.setIsOneWay(((RadioButton) findViewById(R.id.onewayRadio)).isChecked());
                      newTicket.setName(((EditText) findViewById(R.id.nameInput)).getText());

                      Log.d("Created Ticket:", newTicket.toString());
                      ticketList.add(newTicket);

                      Intent i = new Intent(getBaseContext(), PrintActivity.class);
                      i.putExtra("ticket", newTicket);
                      startActivity(i);

                  }
              }

            );
        }
    }
