//File: Ticket
//Assignment #: HW02
//Group 18
//Name: Michael Pedersen, Gabriel Lima,praveenkumar Sangalad

package com.example.gbl.homework02;

import android.text.Editable;

import java.io.Serializable;

/**
 * Created by aoi on 2/8/16.
 */
public class Ticket implements Serializable{
    private String departureTime;
    private String departureDate;
    private String returnTime;
    private String returnDate;
    private String source;
    private String destination;
    private String name;
    private boolean isOneWay;

    public Ticket(){

    }
    public Ticket(String departureTime, String departureDate, String name, String source, String destination, boolean isOneWay) {
        this.departureTime = departureTime;
        this.departureDate = departureDate;
        this.name = name;
        this.source = source;
        this.destination = destination;
        this.isOneWay = isOneWay;
    }

    public String getReturnTime() {
        return returnTime;
    }

    public void setReturnTime(Editable returnTime) {
        this.returnTime = returnTime.toString();
    }

    public String getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(Editable returnDate) {
        this.returnDate = returnDate.toString();
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public String getDepartureDate() {
        return departureDate;
    }

    public String getSource() {
        return source;
    }

    public String getDestination() {
        return destination;
    }

    public String getName() {
        return name;
    }

    public boolean isOneWay() {
        return isOneWay;
    }

    public void setDepartureDate(Editable departureDate) {
        this.departureDate = departureDate.toString();
    }

    public void setDepartureTime(Editable departureTime) {
        this.departureTime = departureTime.toString();
    }

    public void setSource(Editable source) {
        this.source = source.toString();
    }

    public void setDestination(Editable destination) {
        this.destination = destination.toString();
    }

    

    public void setName(Editable name) {
        this.name = name.toString();
    }

    public void setIsOneWay(boolean isOneWay) {
        this.isOneWay = isOneWay;
    }

    @Override
    public String toString() {
        return "Ticket{" +
                "departureTime='" + departureTime + '\'' +
                ", departureDate='" + departureDate + '\'' +
                ", source='" + source + '\'' +
                ", destination='" + destination + '\'' +
                ", name='" + name + '\'' +
                ", isOneWay=" + isOneWay +
                '}';
    }
}
