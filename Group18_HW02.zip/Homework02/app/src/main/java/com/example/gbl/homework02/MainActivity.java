//File: MainActivity
//Assignment #: HW02
//Group 18
//Name: Michael Pedersen, Gabriel Lima,praveenkumar Sangalad

package com.example.gbl.homework02;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    ArrayList<Ticket> ticketList = new ArrayList<Ticket>();
    static int PASS_EDITED_DATA = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.FinishButton).setOnClickListener(this);
        findViewById(R.id.EditTicketButton).setOnClickListener(this);
        findViewById(R.id.DeleteTicketButton).setOnClickListener(this);
        findViewById(R.id.CustomerCareText).setOnClickListener(this);
        findViewById(R.id.CreateTicketButton).setOnClickListener(this);
        findViewById(R.id.ViewTicketButton).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent i;
        switch(v.getId()){
            case R.id.FinishButton:
                finish();
                break;
            case R.id.EditTicketButton:
                i = new Intent(MainActivity.this, EditTicket.class);
                startActivityForResult(i, PASS_EDITED_DATA);

                break;
            case R.id.DeleteTicketButton:
                i = new Intent(MainActivity.this, DeleteTicket.class);
                startActivity(i);
                break;
            case R.id.CustomerCareText:
                i = new Intent(Intent.ACTION_CALL, Uri.parse("tel:999-999-9999"));
                break;
            case R.id.CreateTicketButton:
                i = new Intent(getBaseContext(), CreateTicket.class);
                startActivity(i);
                break;
            case R.id.ViewTicketButton:
                i = new Intent(getBaseContext(), ViewTicket.class);
                startActivity(i);
                break;
        }
    }


}
