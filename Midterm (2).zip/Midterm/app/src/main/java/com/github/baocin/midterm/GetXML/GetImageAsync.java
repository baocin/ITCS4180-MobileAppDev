package com.github.baocin.midterm.GetXML;

//Michael Pedersen
//800810806

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

/**
 * Created by aoi on 2/20/16.
 */
public class GetImageAsync extends AsyncTask<String, Void, Bitmap> {

    private ProgressDialog pDialog;

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
//        pDialog.show();
    }

    @Override
    protected void onPostExecute(Bitmap bm) {
        super.onPostExecute(bm);
//        pDialog.hide();
    }

    @Override
    protected Bitmap doInBackground(String... params) {
        try {
            URL url = new URL(params[0]);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            Bitmap bm = BitmapFactory.decodeStream(con.getInputStream());
            return bm;
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
}
