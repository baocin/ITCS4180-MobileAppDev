//Michael Pedersen
//800810806

package com.github.baocin.midterm;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by aoi on 3/21/16.
 */
public class VenueAdapter extends ArrayAdapter<Venue> {
    private final Context c;
    private final ArrayList<Venue> venueItems;
    SharedPreferences sp;

    public VenueAdapter(Context context, int resource, ArrayList<Venue> objects, SharedPreferences sp) {
        super(context, resource, objects);
        c = context;
        venueItems = objects;

        this.sp = sp;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater;
        ViewHolder holder;


        if (convertView == null) {
            inflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.venue_listitem, parent, false);

            holder = new ViewHolder();
            holder.thumb = (ImageView) convertView.findViewById(R.id.itemThumbnail);
            holder.award = (ImageView) convertView.findViewById(R.id.itemAward);
            holder.checked = (ImageView) convertView.findViewById(R.id.itemCheck);
            holder.category = (TextView) convertView.findViewById(R.id.itemCategory);
            holder.name = (TextView) convertView.findViewById(R.id.itemName);
            convertView.setTag(holder);
        }

        holder = (ViewHolder) convertView.getTag();

        holder.name.setText(venueItems.get(position).getVenueName());
        holder.category.setText(venueItems.get(position).getCategoryName());

        Integer checkInCount = Integer.parseInt(venueItems.get(position).getCheckInCount());
        if (checkInCount <= 100) { holder.award.setImageResource(R.drawable.bronze);}
        if (checkInCount > 100 && checkInCount <= 500) { holder.award.setImageResource(R.drawable.silver);}
        if (checkInCount > 500) { holder.award.setImageResource(R.drawable.gold);}

//        try {
//            AsyncTask<String, Void, Bitmap> result = new GetImageAsync().execute(venueItems.get(position).getCategoryIcon());
//            holder.thumb.setImageBitmap(result.get());
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        } catch (ExecutionException e) {
//            e.printStackTrace();
//        }
        Picasso.with(c).load(venueItems.get(position).getCategoryIcon()).into(holder.thumb);

        //
        //holder.checked

        if (sp.contains(venueItems.get(position).getVenueID())) {
            holder.checked.setImageResource(R.drawable.visited);
        } else {
            holder.checked.setImageResource(R.drawable.unvisited);
        }

        return convertView;
    }

    public VenueAdapter(Context context, int resource, List<Venue> objects) {
        super(context, resource, objects);
        venueItems = null;
        c = null;
    }

    static class ViewHolder {
        ImageView thumb;
        ImageView award;
        ImageView checked;

        TextView name;
        TextView category;

    }
}
