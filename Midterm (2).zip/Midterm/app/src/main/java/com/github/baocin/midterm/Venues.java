//Michael Pedersen
//800810806
package com.github.baocin.midterm;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.ParseException;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.github.baocin.midterm.GetXML.RequestParams;
import com.github.baocin.midterm.GetXML.Util;

import org.json.JSONException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class Venues extends AppCompatActivity {
    VenueAdapter va = null;
    SharedPreferences sp = null;
    SharedPreferences.Editor spEdit = null;
    ArrayList<Venue> currentVenueList = null;
    public static boolean hideUnMarked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_venues);

        String city = getIntent().getExtras().getString("city");

        sp = getSharedPreferences(MainActivity.prefKey, Context.MODE_PRIVATE);
        spEdit = sp.edit();

//(RelativeLayout) findViewById(R.id.baseLayout)
        new VenueAsync(this, (RelativeLayout) findViewById(R.id.baseLayout)).execute(city);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.venue_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    protected void onResume() {
        super.onResume();

        hideUnMarked = false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.clearMarkedVenues:
                //CLEARS all marked venues (from everywhere)
                spEdit.clear();
                spEdit.commit();

                updateMarkedStatus();

                va.notifyDataSetChanged();
                return true;

            case R.id.viewMarkedVenues:
                //FILTERS the current list of venues to only the ones marked
                hideUnMarked = true;
                ArrayList<Venue> onlySelectedVenues = new ArrayList<>();
                for (Venue v : currentVenueList){
                    if (sp.contains(v.getVenueID())){
                        onlySelectedVenues.add(v);
                    }
                }
                va = new VenueAdapter(getApplicationContext(), R.layout.venue_listitem, onlySelectedVenues, sp);
                final ListView venueListView = (ListView) findViewById(R.id.venueListView);
                venueListView.setAdapter(va);

                va.notifyDataSetChanged();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }


    public class VenueAsync extends AsyncTask<String, Void, ArrayList<Venue>> {
        private final RelativeLayout layout;
        ProgressDialog pd;
        Context context;
        private String clientID = "12CU5R0TKXB0FKIYGH50ZVQXWAY4V3S11WAEXWTFT1LIAIUG";
        private String clientSecret = "YXTQ4AGZF3UD4YHHWNTSLROW3HSYL1LP0YCBOWQCW3IUTD3I";
        SharedPreferences sp = null;

        public VenueAsync(Context context, RelativeLayout layout){
            this.context = context;
            this.layout = layout;

            sp = context.getSharedPreferences(MainActivity.prefKey, Context.MODE_PRIVATE);
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            //Make Progress Dialog
            pd = new ProgressDialog(context);
            pd.setCancelable(false);
            pd.setMessage(context.getString(R.string.loadingText));
            pd.setIndeterminate(true);
            pd.show();

        }

        @Override
        protected void onPostExecute(ArrayList<Venue> venueList) {
            super.onPostExecute(venueList);

            currentVenueList = venueList;

            //Update List View
            va = new VenueAdapter(getApplicationContext(), R.layout.venue_listitem, venueList, sp);
            final ListView venueListView = (ListView) findViewById(R.id.venueListView);
            venueListView.setAdapter(va);

            venueListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
                @Override
                public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                    Venue currentVenue = (Venue) venueListView.getItemAtPosition(position);

                    if (sp.contains(currentVenue.getVenueID())) {
                        spEdit.remove(currentVenue.getVenueID());
                        spEdit.commit();
                        Toast.makeText(getApplicationContext(), "Removed: " + currentVenue.getVenueName().toString(), Toast.LENGTH_SHORT).show();

                        updateMarkedStatus();

                        va.notifyDataSetChanged();
                    } else {
                        spEdit.putString(currentVenue.getVenueID().toString(), currentVenue.getVenueName());
                        spEdit.commit();
                        Toast.makeText(getApplicationContext(), "Successfully Marked: " + currentVenue.getVenueName().toString(), Toast.LENGTH_SHORT).show();

                        va.notifyDataSetChanged();
                    }
                    return false;
                }
            });

            //Dismiss Progress Dialog
            pd.dismiss();
        }

        @Override
        protected ArrayList<Venue> doInBackground(String... params) {
            //Calling Parser
            try {
                //Add Parameters
                String city = params[0];

                Date nowDate = new Date();
                Calendar c = Calendar.getInstance();
                System.out.println("Current time => " + c.getTime());
                //CHECK THIS
                SimpleDateFormat df = new SimpleDateFormat("yyyyMMd");
                String formattedDate = df.format(c.getTime());

                String baseApiUrl = "https://api.foursquare.com/v2/venues/search";
                RequestParams pr = new RequestParams(baseApiUrl);
                pr.addParam("client_id", clientID);
                pr.addParam("client_secret", clientSecret);
                pr.addParam("v", formattedDate);
                pr.addParam("near", city);

//                String apiUrl = "https://api.foursquare.com/v2/venues/search?client_id=" + clientID + "&client_secret=" + clientSecret + "&v=" + formattedDate + "&near=" + city;

                Log.d("apiurl", pr.getEncodedURL());
                //Connect
                URL url = new URL(pr.getEncodedURL());
                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                con.setRequestMethod("GET");
                con.connect();

                //Get status
                int statusCode = con.getResponseCode();
                Log.d("connection status", statusCode + "");
                if (statusCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    StringBuilder sb = new StringBuilder();
                    String line = reader.readLine();
                    while (line != null) {
                        sb.append(line);
                        line = reader.readLine();

                    }

                    return Util.JSONParser.parseVenues(sb.toString());

                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            } catch (java.text.ParseException e) {
                e.printStackTrace();
            }


            return null;
        }
    }

    private void updateMarkedStatus() {
        if (hideUnMarked) {
            ArrayList<Venue> onlySelectedVenues = new ArrayList<>();
            for (Venue v : currentVenueList){
                if (sp.contains(v.getVenueID())){
                    onlySelectedVenues.add(v);
                }
            }
            va = new VenueAdapter(getApplicationContext(), R.layout.venue_listitem, onlySelectedVenues, sp);
            final ListView venueListView = (ListView) findViewById(R.id.venueListView);
            venueListView.setAdapter(va);

            va.notifyDataSetChanged();

        }
    }
}
