//Michael Pedersen
//800810806
package com.github.baocin.midterm.GetXML;

import android.util.Log;

import com.github.baocin.midterm.Venue;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.util.ArrayList;

/**
 * Created by aoi on 3/21/16.
 */
public class Util {
    static public class JSONParser {
        public static ArrayList<Venue> parseVenues(String in) throws JSONException, ParseException {
            ArrayList<Venue> VenueList = new ArrayList<Venue>();
            JSONObject root = new JSONObject(in).getJSONObject("response");
//            String category = root.getString("response");
            Log.d("jsonObjectRoot", root.toString());
            JSONArray venueJSONArray = root.getJSONArray("venues");
            for (int i = 0; i < venueJSONArray.length(); i++){
                try {       //Just Do it!
                    JSONObject venueJSONObject = venueJSONArray.getJSONObject(i);
                    Log.d("jsonObject", venueJSONObject.toString());
                    Venue venue = new Venue();
                    venue.setVenueID(venueJSONObject.getString("id"));
                    venue.setVenueName(venueJSONObject.getString("name"));
                    JSONObject categoryObject = null;

                    categoryObject = venueJSONObject.getJSONArray("categories").getJSONObject(0);

                    JSONObject icon = categoryObject.getJSONObject("icon");
                    venue.setCategoryName(categoryObject.getString("name"));
                    venue.setCategoryIcon(icon.getString("prefix") + "bg_64" + icon.getString("suffix"));
                    venue.setCheckInCount(venueJSONObject.getJSONObject("stats").getString("checkinsCount"));
                    VenueList.add(venue);

                }catch(JSONException e){
                    e.printStackTrace();
                }
            }

            Log.d("done", VenueList.toString());
            return VenueList;
        }
    }
}
