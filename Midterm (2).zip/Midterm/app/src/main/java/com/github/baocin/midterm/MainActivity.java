//Michael Pedersen
//800810806

package com.github.baocin.midterm;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private String selectedCity;
    final public static String prefKey = "PREFERENCES";
    VenueAdapter va = null;
    SharedPreferences sp = null;
    SharedPreferences.Editor spEdit = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setIcon(R.drawable.logo);

        sp = getSharedPreferences(prefKey, Context.MODE_PRIVATE);
        spEdit = sp.edit();

        Spinner spinner = (Spinner)findViewById(R.id.main_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.cities, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String[] sections = getResources().getStringArray(R.array.cities);
                selectedCity = sections[position];

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedCity = "";
            }
        });

        findViewById(R.id.main_submit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedCity!=null && selectedCity.equals("")) {
                    Toast.makeText(getApplicationContext(), R.string.nothingSelectedError, Toast.LENGTH_SHORT).show();
                } else {
                    if (!isNetworkAvailable()){
                        Toast.makeText(getApplicationContext(), R.string.noInternetError, Toast.LENGTH_SHORT).show();
                    }

                    Intent i = new Intent(MainActivity.this, Venues.class);
                    i.putExtra("city", selectedCity);
                    startActivity(i);
                }
            }
        });
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }







}
