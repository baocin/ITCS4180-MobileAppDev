/*
Assignment #: 2
FileName: MainActivity.java
Full Name: Michael Pedersen
 */
package com.github.baocin.inclass2b;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    static double conversionRatio = 0;
    private static String TAG = "MAIN ACTIVITY";
    private RadioGroup rg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rg = (RadioGroup) findViewById(R.id.radioGroup);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                RadioButton rb = (RadioButton) findViewById(i);
                String selectedRadioButton = rb.getText().toString();
//                Log.d(TAG, selectedRadioButton);
            }
        });

        findViewById(R.id.convertButton).setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View view) {
                EditText textbox = (EditText) findViewById(R.id.distanceInput);
                String inputMetersText = textbox.getText().toString();
                TextView resultPrompt = (TextView) findViewById(R.id.resultPrompt);
                TextView results = (TextView) findViewById(R.id.resultTextView);
                double inputMeters = 0;

                switch(rg.getCheckedRadioButtonId()){
                    case R.id.toInchesRadio:
                        conversionRatio = 39.3701;
                        resultPrompt.setHint(getString(R.string.inchesPrompt));
                        break;
                    case R.id.toFeetRadio:
                        conversionRatio = 3.28;
                        resultPrompt.setHint(getString(R.string.feetHint));
                        break;
                    case R.id.toMilesRadio:
                        conversionRatio = 0.0006;
                        resultPrompt.setHint(getString(R.string.distancePrompt));
                        break;
                    case R.id.clearAllRadio:
                        clearAll();
                        break;

                }

                try{
                    Double result = parse(inputMetersText);

                    results.setText(result.toString());

                }catch(Exception e){
                    Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }


            }


        });
    }

    private double parse(String str) {
        if (str.isEmpty()) {
            throw new NumberFormatException(getString(R.string.emptyError));
        }
        double inputMeters = 0;
        try {
            inputMeters = Double.parseDouble(str);
            if (inputMeters < 0){
                throw new Exception("No Negatives!");
            }
        } catch (Exception e) {
            throw new NumberFormatException(getString(R.string.errorParsing));
        }

        return conversionRatio * inputMeters;

    }

    public void clearAll(){
        EditText textbox = (EditText)findViewById(R.id.distanceInput);
        TextView results = (TextView) findViewById(R.id.resultTextView);
        TextView resultPrompt = (TextView) findViewById(R.id.resultPrompt);
        textbox.setText(getString(R.string.empty));
        textbox.setHint(getString(R.string.distanceHint));
        results.setText(getString(R.string.empty));
        resultPrompt.setHint(getString(R.string.resultPrompt));
    }
}
