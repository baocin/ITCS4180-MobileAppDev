
/*
Assignment #: 2a
FileName: MainActivity.java
Full Name: Michael Pedersen
 */

package com.github.baocin.inclass2a;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    private double calc(String str, char type){
        if (str.isEmpty()){
            throw new NumberFormatException(getString(R.string.emptyError));
        }
        double inputMeters = 0;
        try {
            inputMeters = Double.parseDouble(str);
            if (inputMeters < 0){
                throw new NumberFormatException(getString(R.string.negativeError));
            }
        }catch (Exception e){
            throw new NumberFormatException(getString(R.string.errorParsing));
        }

        double conversion = 0;
        switch(type){
            case 'i':
                conversion = 39.3701;
                break;
            case 'f':
                conversion = 3.28;
                break;
            case 'm':
                conversion = 0.0006;
                break;
        }

        return conversion * inputMeters;

    }

    public void toInches(View v){
        EditText textbox = (EditText)findViewById(R.id.distanceInput);
        String inputMetersText = textbox.getText().toString();
        TextView resultPrompt = (TextView) findViewById(R.id.resultPrompt);
        TextView results = (TextView) findViewById(R.id.resultTextView);
        try{
            Double result = calc(inputMetersText, 'i');
            results.setText(result.toString());
            resultPrompt.setHint(getString(R.string.inchesPrompt));
        }catch(Exception e){
            Toast.makeText(this.getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void toFeet(View v){
        EditText textbox = (EditText)findViewById(R.id.distanceInput);
        String inputMetersText = textbox.getText().toString();
        TextView resultPrompt = (TextView) findViewById(R.id.resultPrompt);
        TextView results = (TextView) findViewById(R.id.resultTextView);
        try{
            Double result = calc(inputMetersText, 'f');
            results.setText(result.toString());
            resultPrompt.setHint(getString(R.string.feetHint));
        }catch(Exception e){
            Toast.makeText(this.getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void toMiles(View v){
        EditText textbox = (EditText)findViewById(R.id.distanceInput);
        String inputMetersText = textbox.getText().toString();
        TextView results = (TextView) findViewById(R.id.resultTextView);
        TextView resultPrompt = (TextView) findViewById(R.id.resultPrompt);
        try{
            Double result = calc(inputMetersText, 'm');
            results.setText(result.toString());
            resultPrompt.setHint("Miles:");
        }catch(Exception e){
            Toast.makeText(this.getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void clearAll(View v){
        EditText textbox = (EditText)findViewById(R.id.distanceInput);
        TextView results = (TextView) findViewById(R.id.resultTextView);
        TextView resultPrompt = (TextView) findViewById(R.id.resultPrompt);
        textbox.setText(getString(R.string.empty));
        textbox.setHint(getString(R.string.distanceHint));
        results.setText(getString(R.string.empty));
        resultPrompt.setHint(getString(R.string.resultPrompt));
    }

}
