/*
 * Assignment #: 01
 * FileName: InClassOn
 * Full Name: Michael Pedersen
*/

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;

public class InClassOn {
	private static ArrayList<Movie> moviesList;
	private static LinkedHashMap<Character, ArrayList<Movie>> movieTable;
	
	public static void main(String[] args) {
		moviesList = new ArrayList<Movie>();
		movieTable = new LinkedHashMap<Character, ArrayList<Movie>>();
		
		//Read in the movie data and populate the arraylist and hashtable
		readFileAtPath("topmovies.csv");
		
		//Print in order of revenue descending
		System.out.println("Movies sorted in descending order of total revenue: ");
		Collections.sort(moviesList);
		for (Movie m : moviesList){
			System.out.println(m);
		}
		
		//Print based on first letter
		System.out.println("\nPrint movies based on first letter");
		for(char key : movieTable.keySet()){
			System.out.print(key + ": ");
			Iterator<Movie> movieIterator = movieTable.get(key).iterator();
			while (movieIterator.hasNext()){
				System.out.print(movieIterator.next().getTitle());
				if (movieIterator.hasNext()){
					System.out.print(", ");
				}
			}
			System.out.println();
		}
	}

	public static void readFileAtPath(String filename) {
		// Lets make sure the file path is not empty or null
		if (filename == null || filename.isEmpty()) {
			System.out.println("Invalid File Path");
			return;
		}
		String filePath = System.getProperty("user.dir") + "/" + filename;
		BufferedReader inputStream = null;
		// We need a try catch block so we can handle any potential IO errors
		try {
			try {
				inputStream = new BufferedReader(new FileReader(filePath));
				String lineContent = null;
				// Loop will iterate over each line within the file.
				// It will stop when no new lines are found.
				while ((lineContent = inputStream.readLine()) != null) {
					//Attempt to parse the movie line - skip if it cannot
					try {
						Movie parsedMovie = new Movie();
						parsedMovie.parseMovie(lineContent);
						moviesList.add(parsedMovie);
						
						char firstCharacterOfMovieName = parsedMovie.getTitle().toUpperCase().charAt(0);
						if (movieTable.get(firstCharacterOfMovieName) == null){
							//Hashtable does not contain key yet, add it
							movieTable.put(firstCharacterOfMovieName, new ArrayList<Movie>());
							
						}
						movieTable.get(firstCharacterOfMovieName).add(parsedMovie);
					}catch(Exception e){
						//Ignore errors - continue parsing next line
						continue;
					}
				}
			}
			// Make sure we close the buffered reader.
			finally {
				if (inputStream != null)
					inputStream.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	// end of method
}
