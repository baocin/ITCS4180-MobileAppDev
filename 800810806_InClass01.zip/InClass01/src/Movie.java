/*
 * Assignment #: 01
 * FileName: Movie
 * Full Name: Michael Pedersen
*/		
public class Movie implements Comparable<Movie>{
	private int year;
	private String title;
	private double revenue;
	
	@Override
	public String toString() {
//		StringBuilder sb = new StringBuilder();
//		sb.append(year);a
		return "Movie [year=" + year + ", title=" + title + ", revenue=" + revenue + "]";
	}
	
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getRevenue() {
		return revenue;
	}
	public void setRevenue(double revenue) {
		this.revenue = revenue;
	}
	
	public void parseMovie(String line) {
		String[] splitMovieLine = line.split(",");
		this.setYear(Integer.parseInt(splitMovieLine[0].trim()));
		this.setTitle(splitMovieLine[1].trim());
		this.setRevenue(Double.parseDouble(splitMovieLine[2].trim()));
	}
	
	public int compareTo(Movie b){
		if (this.revenue > b.getRevenue()){
			return -1;
		}else if (this.revenue < b.getRevenue()){
			return 1;
		}
		return 0;
	}
	
}
