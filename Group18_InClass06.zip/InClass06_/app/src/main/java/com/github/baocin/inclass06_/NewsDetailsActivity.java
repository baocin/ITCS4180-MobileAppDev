package com.github.baocin.inclass06_;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class NewsDetailsActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageView newsImage;
    News news;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_details);

         news = (News) getIntent().getExtras().get("news");

        ((TextView)findViewById(R.id.newsDescription)).setText(news.getDescription());
        ((TextView)findViewById(R.id.storyPublicationDate)).setText(news.getPublicationDate());
        ((TextView)findViewById(R.id.storyTitle)).setText(news.getTitle());
        ((TextView)findViewById(R.id.newsDescriptionTitle)).setText("Description");


        newsImage = (ImageView) findViewById(R.id.newsImage);
        newsImage.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.newsImage:
                Log.d("CLICK", "");
                Intent i = new Intent(NewsDetailsActivity.this, NewsWebView.class);
                Log.d("PUTTING URL:", news.getLink());
                i.putExtra("url", news.getLink());
                startActivity(i);
                break;
        }
    }
}
