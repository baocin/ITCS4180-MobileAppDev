package com.github.baocin.inclass06_;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class NewsWebView extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_web_view);

        final String url = getIntent().getExtras().getString("url");

//        Log.d("Loaded webview", "yeah");
        Log.d("URL:", url);
        WebView wv = (WebView) findViewById(R.id.webview);
        wv.loadUrl(url);
//        wv.setWebViewClient(new WebViewClient() {
//            @Override
//            public boolean shouldOverrideUrlLoading(WebView view, String url) {
//                view.loadUrl(url);
//                return false;
//            }
//        });




    }
}
