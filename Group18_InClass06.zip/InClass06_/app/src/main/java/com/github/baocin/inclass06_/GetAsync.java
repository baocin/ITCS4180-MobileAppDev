package com.github.baocin.inclass06_;

import android.os.AsyncTask;

/**
 * Created by aoi on 2/22/2016.
 */
public class GetAsync extends AsyncTask<Void, Void, Void> {
        final String apiURL = "";

    @Override
    protected Void doInBackground(Void... params) {
        return null;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);
    }
}
