package com.github.baocin.inclass06_;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.ExecutionException;

public class NewsActivity extends AppCompatActivity implements View.OnClickListener {

    private ProgressDialog progressDialog;
    private ArrayList<String> topics;
    private ImageView newsImage;
    ArrayList<News> newsData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);

        String url = getIntent().getExtras().getString("url");

        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Loading News...");
        progressDialog.show();

        ArrayList<String> topics = new ArrayList<>();
        try {
            newsData = new GetData().execute(url).get();
            Log.d("News Data", newsData.toString());
//            Collections.sort(newsData);

            for (News n : newsData){
                Log.d("news", n.toString());
                topics.add(n.getTitle());
            }

            TableLayout scrollItems = (TableLayout) findViewById(R.id.scrollItems);
            int id = 0;
            for (String topicName : topics) {
                View item = getLayoutInflater().inflate(R.layout.list_item_story, null);

                item.setId(id);
                item.setTag(topicName);
                item.setOnClickListener(this);
                ((TextView) item.findViewById(R.id.storyTitle) ).setText(topicName);
                scrollItems.addView(item);
                id += 1;

            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

        progressDialog.dismiss();




    }

    @Override
    public void onClick(View v) {
        String storyName = (String) v.getTag();
        for (News n : newsData){
            if (n.getTitle().equals(storyName)){
                Intent i = new Intent(NewsActivity.this, NewsDetailsActivity.class);
                i.putExtra("news", n);
                //Send story url
                startActivity(i);
            }
        }
        switch(v.getId()){
//            case R.id.newsImage:
//                Intent i = new Intent(NewsActivity.this, NewsWebView.class);
//                i.putExtra("url", "www.google.com");
//                startActivity(i);
//                break;
        }
//        String url = "";
//        v.getId();
//        topics.get(v.getId());
//        Log.d("Selected", url);



    }
}
