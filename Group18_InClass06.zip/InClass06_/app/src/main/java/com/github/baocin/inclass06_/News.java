//File: News
//InClass 06
//2-22-2016
//Praveenkumar Sangalad
//Michael Pedersen
//Gabriel Lima

package com.github.baocin.inclass06_;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by gbl on 2/22/2016.
 */
public class News implements Comparable<News>, Parcelable {

    private String title;
    private String link;
    private String publicationDate;
    private Bitmap thumbnail;
    private String description;

    protected News(Parcel in) {
        title = in.readString();
        link = in.readString();
        publicationDate = in.readString();
        thumbnail = in.readParcelable(Bitmap.class.getClassLoader());
        description = in.readString();
    }

    public static final Creator<News> CREATOR = new Creator<News>() {
        @Override
        public News createFromParcel(Parcel in) {
            return new News(in);
        }

        @Override
        public News[] newArray(int size) {
            return new News[size];
        }
    };

    public News() {

    }

    @Override
    public String toString() {
        return "News{" +
                "title='" + title + '\'' +
                ", link='" + link + '\'' +
                ", publicationDate='" + publicationDate + '\'' +
                ", thumbnail=" + thumbnail +
                ", description='" + description + '\'' +
                '}';
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getTitle() {
        return title;
    }

    public String getPublicationDate() {
        return publicationDate;
    }

    public Bitmap getThumbnail() {
        return thumbnail;
    }

    public String getDescription() {
        return description;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setPublicationDate(String publicationDate) {
        this.publicationDate = publicationDate;
    }

    public void setThumbnail(Bitmap thumbnail) {
        this.thumbnail = thumbnail;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public int compareTo(News another) {
        SimpleDateFormat sdf = new SimpleDateFormat("ccc, DD MMM yyyy k:m:s a");
//        Mon, 22 Feb 2016 14:52:00 PST'
        try {
            Date thisDate = sdf.parse(this.getPublicationDate());
            Date otherDate = sdf.parse(another.getPublicationDate());
            Log.d("Date vs", thisDate + " vs "+ otherDate);
            return thisDate.compareTo(otherDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return 0;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

        dest.writeString(title);
        dest.writeString(link);
        dest.writeString(publicationDate);
        dest.writeParcelable(thumbnail, flags);
        dest.writeString(description);
    }
}
