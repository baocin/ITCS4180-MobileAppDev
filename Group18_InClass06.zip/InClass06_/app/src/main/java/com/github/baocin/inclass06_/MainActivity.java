//File: MainActivity
//InClass 06
//2-22-2016
//Praveenkumar Sangalad
//Michael Pedersen
//Gabriel Lima


package com.github.baocin.inclass06_;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ScrollView topicsList = (ScrollView) findViewById(R.id.topicList);
        ArrayList<String> topics = new ArrayList<String>();
        topics.add("Most Popular");
        topics.add("Entertainment");
        topics.add("Health");
        topics.add("Lifestyle");
        topics.add("Opinion");
        topics.add("Politics");
        topics.add("Science");
        topics.add("Sports");
        topics.add("Tech");

        TableLayout scrollItems = (TableLayout) findViewById(R.id.scrollItems);

        Log.d("topics", topics + "");
        int id = 0;
        for (String topicName : topics) {
            View item = getLayoutInflater().inflate(R.layout.list_item, null);
            item.setId(id);
            item.setTag(topicName);
            item.setOnClickListener(this);
            ((TextView) item.findViewById(R.id.name) ).setText(topicName);
            scrollItems.addView(item);
            id +=1;
        }

    }

    @Override
    public void onClick(View v) {
        String url = "";
        switch(v.getId()){
            case 0:
//                Intent i = new Intent(MainActivity.this, NewsWebView.class);
//                i.putExtra("url", "https://www.google.com");
//                startActivity(i);
                url = "http://feeds.foxnews.com/foxnews/most-popular";
                break;
            case 1:
                url = "http://feeds.foxnews.com/foxnews/entertainment";
                break;
            case 2:
                url = "http://feeds.foxnews.com/foxnews/health";
                break;
            case 3:
                url = "http://feeds.foxnews.com/foxnews/section/lifestyle";
                break;
            case 4:
                url = "http://feeds.foxnews.com/foxnews/opinion";
                break;
            case 5:
                url = "http://feeds.foxnews.com/foxnews/politics";
                break;
            case 6:
                url = "http://feeds.foxnews.com/foxnews/science";
                break;
            case 7:
                url = "http://feeds.foxnews.com/foxnews/sports";
                break;
            case 8:
                url = "http://feeds.foxnews.com/foxnews/tech";
                break;
            case 9:
                url = "http://feeds.foxnews.com/foxnews/internal/travel/mixed";
                break;
            case 10:
                url = "http://feeds.foxnews.com/foxnews/national";
                break;
        }
        Log.d("Selected", url);

        Intent i = new Intent(MainActivity.this, NewsActivity.class);
        i.putExtra("url", url);
        startActivity(i);

    }


}
