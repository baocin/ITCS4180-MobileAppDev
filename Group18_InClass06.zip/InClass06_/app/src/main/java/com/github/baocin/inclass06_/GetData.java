//File: Get Data
//InClass 06
//2-22-2016
//Praveenkumar Sangalad
//Michael Pedersen
//Gabriel Lima

package com.github.baocin.inclass06_;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.util.ArrayList;

public class GetData  extends AsyncTask<String, Void, ArrayList<News>> {

        @Override
        protected ArrayList<News> doInBackground(String... params) {

            Log.d("TEST", "RODOU");

            ArrayList<News> aux = null;

            try {

                aux = FeedReader.NewsPullParser.ParseNews(params[0]);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (XmlPullParserException e) {
                e.printStackTrace();
            }

            return aux;
        }

        @Override
        protected void onPostExecute(ArrayList<News> newses) {
            Log.d("TEST", newses.toString());

        }

}
